# SERE — Self-Evolving Research Engine

## What This Is

A research program manager with git-backed reproducibility and NLRL-based policy evolution. You (Claude Code) are the execution engine.

## Project Structure

```
sere/
├── models.py       # Data models: Program, Phase, Track, Experiment, Policy
├── store.py        # Git-backed storage (every state change = git commit)
├── engine.py       # Phase state machine: diverge → converge → exploit
├── evolution.py    # NLRL prompt generation for policy evolution
└── cli.py          # CLI entrypoint
```

## Key Commands

```bash
sere init                                    # Initialize workspace
sere program create --name "X" --hypothesis "Y"
sere program create --from-yaml template.yaml
sere program show <program-id>
sere phase activate <program-id>             # Start next phase
sere track add <prog> <phase> --name "X" --approach "Y"
sere track kill <prog> <phase> <track> --reason "why"
sere track merge <prog> <phase> <track> --notes "insights"
sere exp record <prog> --track T --phase P --name "X" --params '{}'
sere exp complete <exp-id> --metrics '{"recall": 0.7}'
sere exp list --phase P --track T
sere evolve evaluate <prog>                  # → paste to Claude for eval
sere evolve mutate <prog> --eval-json f.json # → paste to Claude for mutation
sere evolve apply <prog> --policy "..." --rationale "..."
sere evolve task <prog> <exp-id>             # → Claude Code task prompt
sere status <prog>
sere log                                     # git audit trail
```

## Research Workflow

When asked to run a research program, follow this loop:

### Phase: Diverge
1. Read the program status: `sere program show <id>`
2. Read the active policy: it's shown in the status output
3. For each track, propose and run experiments:
   - `sere exp record ...` to register
   - Implement and execute the experiment code
   - `sere exp complete <id> --metrics '{...}'` to record results
4. Respect the policy — if it says "kill after 3 failed iterations", kill

### Phase: Converge
1. Compare metrics across all tracks in the phase
2. Use `sere track kill` for underperformers with documented rationale
3. Use `sere track merge` for the winner with insights carried forward
4. `sere phase complete <prog> <phase> --rationale "why winner was chosen"`

### Policy Evolution
When the researcher asks to evolve the policy, or when transitioning phases:
1. Run `sere evolve evaluate <prog>` — analyze the output
2. Run `sere evolve mutate <prog>` — propose 3 mutations
3. Present candidates to the researcher
4. Apply the selected one with `sere evolve apply`

## Conventions

- All experiment parameters should be JSON-serializable
- Metrics should be float values in a flat dict
- Use `--seed` for reproducibility when randomness is involved
- Every decision (kill/merge/advance) needs a documented rationale
- The git log IS the paper trail — write meaningful commit messages

## When Running Experiments

1. Create experiment code in the workspace directory
2. Record the experiment BEFORE running: `sere exp record ...`
3. Run the code, capture metrics
4. Complete the experiment AFTER running: `sere exp complete ...`
5. If it fails, still complete it: `sere exp complete <id> --error "what went wrong"`

## Research Policy

The active policy is a natural language directive that guides decisions.
Always read it before proposing experiments or making kill/merge decisions.
The policy evolves over time via NLRL — each generation builds on the last.
