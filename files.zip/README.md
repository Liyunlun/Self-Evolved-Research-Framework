# SERE — Self-Evolving Research Engine

A framework for managing research programs with parallel tracks, phase transitions, and NLRL-based policy evolution. Designed for integration with **Claude Code**.

## Core Concepts

SERE encodes structural principles from high-performing research organizations (DeepMind, Manhattan Project) into a reproducible workflow:

```
Research Program
├── Phase 1: Diverge (Landscape Mapping)
│   ├── Track A: approach 1
│   ├── Track B: approach 2
│   └── Track C: approach 3
├── Phase 2: Diverge (Parallel Evaluation)
│   ├── Track A → experiments → metrics
│   └── Track B → experiments → metrics  (Track C killed)
├── Phase 3: Converge (Selection)
│   └── Winner selected, insights merged
└── Phase 4: Exploit (Scale & Publish)
    └── Scale winning approach, write paper
```

**Self-evolution**: Research policies are natural language directives optimized via NLRL. The framework generates evaluation, mutation, and selection prompts that you feed to Claude Code, closing the loop.

## Quick Start

```bash
# Install
cd sere && pip install -e .

# Initialize workspace
mkdir my-research && cd my-research
sere init

# Create a program (interactive)
sere program create

# Or from a template
sere program create --from-yaml ../templates/memory_nlrl.yaml

# Start the first phase
sere phase activate <program-id>

# Add parallel research tracks
sere track add <program-id> <phase-id> --name "episodic-rag" --approach "RAG with episodic memory consolidation"
sere track add <program-id> <phase-id> --name "semantic-nlrl" --approach "Semantic memory with NLRL-optimized retrieval"

# Record experiments
sere exp record <program-id> --track <track-id> --phase <phase-id> --name "baseline-rag-v1"

# Complete with metrics
sere exp complete <exp-id> --metrics '{"recall": 0.72, "latency_ms": 45}'

# View status
sere status <program-id>

# View audit trail
sere log
```

## Claude Code Integration

SERE generates structured prompts for Claude Code at every stage:

### Running experiments
```bash
# Generate a Claude Code task prompt
sere evolve task <program-id> <experiment-id>

# Pipe directly to Claude Code
sere evolve task <program-id> <experiment-id> | claude --pipe
```

### Evolving research policy
```bash
# Step 1: Evaluate current policy
sere evolve evaluate <program-id> | claude --pipe > eval.json

# Step 2: Generate mutations
sere evolve mutate <program-id> --eval-json eval.json | claude --pipe > mutations.json

# Step 3: Apply the best mutation
sere evolve apply <program-id> --policy "new policy text" --rationale "what changed"
```

### Full evolution loop (scripted)
```bash
#!/bin/bash
PROG="your-program-id"

# Evaluate → Mutate → Apply
EVAL=$(sere evolve evaluate $PROG | claude --pipe --output-format json)
echo "$EVAL" > /tmp/eval.json
MUTATIONS=$(sere evolve mutate $PROG --eval-json /tmp/eval.json | claude --pipe --output-format json)
# Review mutations, then apply the best one
```

## Architecture

```
sere/
├── models.py       # Data models: Program, Phase, Track, Experiment, Policy
├── store.py        # Git-backed storage layer
├── engine.py       # Phase state machine and track management
├── evolution.py    # NLRL evolution engine (prompt generation + policy application)
└── cli.py          # Click-based CLI
```

**Every state change is git-committed**, giving you:
- Full audit trail of all research decisions
- Ability to diff any two points in your research history
- Rollback to any previous state
- Branch for exploratory tangents

## Design Principles

1. **Parallel paths with convergence forcing functions** — Structure exploration, but define concrete milestones that force integration
2. **Hierarchical autonomy** — Goals cascade down (program → phase → track), methods bubble up (experiment → track → phase)
3. **T-shaped resources** — Shared infrastructure (benchmarks, data), independent methodology per track
4. **Embedded evaluation** — Experiments are evaluated against both local track metrics and global program policy
5. **Temporal phasing** — Explicit diverge/converge/exploit transitions with documented rationale
