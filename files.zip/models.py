"""
SERE Data Models — Research Programs, Phases, Experiments, Evolution Policies.

A research program is a state machine:
  Phase(diverge) → Phase(diverge) → Phase(converge) → Phase(exploit)

Each phase contains tracks (parallel research bets).
Each track contains experiments (individual runs with full provenance).
Evolution policies are natural language directives that get mutated by NLRL.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any


class PhaseType(str, Enum):
    DIVERGE = "diverge"
    CONVERGE = "converge"
    EXPLOIT = "exploit"


class PhaseStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    KILLED = "killed"


class ExperimentStatus(str, Enum):
    PLANNED = "planned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    KILLED = "killed"


class TrackStatus(str, Enum):
    ACTIVE = "active"
    MERGED = "merged"
    KILLED = "killed"


@dataclass
class ExperimentConfig:
    """Fully reproducible experiment specification."""
    parameters: dict[str, Any] = field(default_factory=dict)
    code_snapshot: str = ""  # git commit hash or content hash
    dependencies: list[str] = field(default_factory=list)
    seed: int | None = None
    tags: list[str] = field(default_factory=list)

    def content_hash(self) -> str:
        """Deterministic hash for reproducibility verification."""
        canonical = json.dumps(
            {"params": self.parameters, "deps": sorted(self.dependencies), "seed": self.seed},
            sort_keys=True,
        )
        return hashlib.sha256(canonical.encode()).hexdigest()[:12]


@dataclass
class ExperimentResult:
    """Structured experiment output."""
    metrics: dict[str, float] = field(default_factory=dict)
    artifacts: list[str] = field(default_factory=list)  # paths to output files
    logs: str = ""
    error: str | None = None
    duration_seconds: float = 0.0

    @property
    def success(self) -> bool:
        return self.error is None


@dataclass
class Experiment:
    """Single experiment run with full provenance."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    name: str = ""
    hypothesis: str = ""
    config: ExperimentConfig = field(default_factory=ExperimentConfig)
    result: ExperimentResult | None = None
    status: ExperimentStatus = ExperimentStatus.PLANNED
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: str | None = None
    parent_id: str | None = None  # for experiment lineage
    track_id: str | None = None
    phase_id: str | None = None
    notes: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Experiment":
        d = d.copy()
        d["status"] = ExperimentStatus(d["status"])
        if d.get("config"):
            d["config"] = ExperimentConfig(**d["config"])
        if d.get("result"):
            d["result"] = ExperimentResult(**d["result"])
        return cls(**d)


@dataclass
class Track:
    """A parallel research bet within a phase."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    name: str = ""
    approach: str = ""  # natural language description of the approach
    status: TrackStatus = TrackStatus.ACTIVE
    experiments: list[str] = field(default_factory=list)  # experiment IDs
    metrics_history: list[dict[str, float]] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Track":
        d = d.copy()
        d["status"] = TrackStatus(d["status"])
        return cls(**d)


@dataclass
class Phase:
    """A research phase with convergence criteria."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    name: str = ""
    phase_type: PhaseType = PhaseType.DIVERGE
    goal: str = ""
    status: PhaseStatus = PhaseStatus.PENDING
    tracks: list[Track] = field(default_factory=list)
    convergence_criteria: str = ""  # natural language, evaluated by NLRL
    deadline: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    selection_rationale: str = ""  # filled during convergence

    def to_dict(self) -> dict:
        d = {
            "id": self.id,
            "name": self.name,
            "phase_type": self.phase_type.value,
            "goal": self.goal,
            "status": self.status.value,
            "tracks": [t.to_dict() for t in self.tracks],
            "convergence_criteria": self.convergence_criteria,
            "deadline": self.deadline,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "selection_rationale": self.selection_rationale,
        }
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Phase":
        d = d.copy()
        if not d.get("id"):
            d["id"] = uuid.uuid4().hex[:8]
        d["phase_type"] = PhaseType(d["phase_type"])
        d["status"] = PhaseStatus(d["status"])
        d["tracks"] = [Track.from_dict(t) for t in d.get("tracks", [])]
        return cls(**d)


@dataclass
class EvolutionPolicy:
    """Natural language research policy, evolved via NLRL."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    policy_text: str = ""
    domain: str = "general"  # hypothesis | design | allocation | general
    fitness_score: float | None = None
    generation: int = 0
    parent_id: str | None = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    mutation_log: str = ""  # what changed and why

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "EvolutionPolicy":
        d = d.copy()
        if not d.get("id"):
            d["id"] = uuid.uuid4().hex[:8]
        return cls(**d)


@dataclass
class ResearchProgram:
    """Top-level research program — the full state machine."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str = ""
    hypothesis: str = ""  # overarching research hypothesis
    description: str = ""
    phases: list[Phase] = field(default_factory=list)
    evolution_policies: list[EvolutionPolicy] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def current_phase(self) -> Phase | None:
        for phase in self.phases:
            if phase.status == PhaseStatus.ACTIVE:
                return phase
        return None

    @property
    def next_phase(self) -> Phase | None:
        for phase in self.phases:
            if phase.status == PhaseStatus.PENDING:
                return phase
        return None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "hypothesis": self.hypothesis,
            "description": self.description,
            "phases": [p.to_dict() for p in self.phases],
            "evolution_policies": [e.to_dict() for e in self.evolution_policies],
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ResearchProgram":
        d = d.copy()
        # Generate ID if empty (e.g. from templates)
        if not d.get("id"):
            d["id"] = uuid.uuid4().hex[:12]
        d["phases"] = [Phase.from_dict(p) for p in d.get("phases", [])]
        d["evolution_policies"] = [
            EvolutionPolicy.from_dict(e) for e in d.get("evolution_policies", [])
        ]
        return cls(**d)
