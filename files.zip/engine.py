"""
SERE Phase Engine — manages phase transitions and convergence.

The phase engine implements the structural principles:
  1. Parallel paths with convergence forcing functions
  2. Hierarchical autonomy (goals cascade, methods bubble up)
  3. Temporal phasing (diverge → converge → diverge)

Phase transitions are triggered by:
  - Manual advancement (researcher decides)
  - Convergence criteria evaluation (NLRL-assisted)
  - Deadline expiration
"""

from __future__ import annotations

from datetime import datetime, timezone

from .models import (
    Phase,
    PhaseStatus,
    PhaseType,
    ResearchProgram,
    Track,
    TrackStatus,
)
from .store import Store


class PhaseEngine:
    """Manages phase transitions for a research program."""

    def __init__(self, store: Store):
        self.store = store

    def activate_next_phase(self, program: ResearchProgram) -> Phase | None:
        """Advance to the next pending phase."""
        current = program.current_phase
        if current and current.status == PhaseStatus.ACTIVE:
            raise ValueError(
                f"Phase '{current.name}' is still active. "
                "Complete or kill it before advancing."
            )

        next_phase = program.next_phase
        if not next_phase:
            return None

        next_phase.status = PhaseStatus.ACTIVE
        next_phase.started_at = datetime.now(timezone.utc).isoformat()
        self.store.save_program(program, f"Activate phase: {next_phase.name}")
        return next_phase

    def complete_phase(
        self,
        program: ResearchProgram,
        phase_id: str,
        rationale: str = "",
    ) -> Phase:
        """Mark a phase as completed with rationale."""
        phase = self._get_phase(program, phase_id)
        phase.status = PhaseStatus.COMPLETED
        phase.completed_at = datetime.now(timezone.utc).isoformat()
        phase.selection_rationale = rationale
        self.store.save_program(program, f"Complete phase: {phase.name}")
        return phase

    def kill_phase(self, program: ResearchProgram, phase_id: str, reason: str = "") -> Phase:
        phase = self._get_phase(program, phase_id)
        phase.status = PhaseStatus.KILLED
        phase.completed_at = datetime.now(timezone.utc).isoformat()
        phase.selection_rationale = reason
        self.store.save_program(program, f"Kill phase: {phase.name} — {reason}")
        return phase

    # ── Track management ──────────────────────────────────────────

    def add_track(
        self,
        program: ResearchProgram,
        phase_id: str,
        name: str,
        approach: str,
    ) -> Track:
        """Add a parallel research track to a phase."""
        phase = self._get_phase(program, phase_id)
        if phase.status != PhaseStatus.ACTIVE:
            raise ValueError(f"Phase '{phase.name}' is not active.")

        track = Track(name=name, approach=approach)
        phase.tracks.append(track)
        self.store.save_program(program, f"Add track: {name} → {phase.name}")
        return track

    def kill_track(
        self,
        program: ResearchProgram,
        phase_id: str,
        track_id: str,
        reason: str = "",
    ) -> Track:
        """Kill an underperforming track."""
        phase = self._get_phase(program, phase_id)
        track = self._get_track(phase, track_id)
        track.status = TrackStatus.KILLED
        track.notes = reason
        self.store.save_program(
            program, f"Kill track: {track.name} — {reason}"
        )
        return track

    def merge_track(
        self,
        program: ResearchProgram,
        phase_id: str,
        track_id: str,
        notes: str = "",
    ) -> Track:
        """Merge a track's insights into the convergence."""
        phase = self._get_phase(program, phase_id)
        track = self._get_track(phase, track_id)
        track.status = TrackStatus.MERGED
        track.notes = notes
        self.store.save_program(
            program, f"Merge track: {track.name}"
        )
        return track

    # ── Status summary ────────────────────────────────────────────

    def get_program_status(self, program: ResearchProgram) -> dict:
        """Generate a structured status report."""
        phases_summary = []
        for phase in program.phases:
            active_tracks = [t for t in phase.tracks if t.status == TrackStatus.ACTIVE]
            killed_tracks = [t for t in phase.tracks if t.status == TrackStatus.KILLED]
            merged_tracks = [t for t in phase.tracks if t.status == TrackStatus.MERGED]

            exps = self.store.list_experiments(phase_id=phase.id)

            phases_summary.append({
                "id": phase.id,
                "name": phase.name,
                "type": phase.phase_type.value,
                "status": phase.status.value,
                "goal": phase.goal,
                "convergence_criteria": phase.convergence_criteria,
                "tracks": {
                    "active": len(active_tracks),
                    "killed": len(killed_tracks),
                    "merged": len(merged_tracks),
                },
                "experiments": {
                    "total": len(exps),
                    "completed": len([e for e in exps if e.status.value == "completed"]),
                    "failed": len([e for e in exps if e.status.value == "failed"]),
                },
            })

        return {
            "program": program.name,
            "hypothesis": program.hypothesis,
            "current_phase": program.current_phase.name if program.current_phase else None,
            "phases": phases_summary,
            "policies": len(program.evolution_policies),
        }

    # ── Helpers ───────────────────────────────────────────────────

    @staticmethod
    def _get_phase(program: ResearchProgram, phase_id: str) -> Phase:
        for phase in program.phases:
            if phase.id == phase_id:
                return phase
        raise ValueError(f"Phase not found: {phase_id}")

    @staticmethod
    def _get_track(phase: Phase, track_id: str) -> Track:
        for track in phase.tracks:
            if track.id == track_id:
                return track
        raise ValueError(f"Track not found: {track_id}")
