"""
SERE Evolution Engine — NLRL-based research policy optimization.

This implements the self-evolving core: natural language policies that
govern research decisions are treated as optimizable objects. The
evolution loop:

  1. Evaluate: Score current policy against experiment outcomes
  2. Reflect: Analyze what worked/failed and why
  3. Mutate: Generate candidate policy mutations
  4. Select: Pick the best mutation based on projected fitness

The key NLRL insight: we optimize in natural language space, where
the "gradient" is a natural language critique and the "update" is
a policy rewrite.

For the MVP, evolution is invoked manually or triggered by the CLI.
Claude Code acts as the LLM backbone for evaluation and mutation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .models import (
    EvolutionPolicy,
    Experiment,
    ExperimentStatus,
    ResearchProgram,
)
from .store import Store


@dataclass
class EvolutionContext:
    """All information needed for a policy evolution step."""
    current_policy: EvolutionPolicy
    recent_experiments: list[Experiment]
    program_status: dict
    constraints: list[str] = field(default_factory=list)


@dataclass
class MutationCandidate:
    """A proposed policy mutation with rationale."""
    policy_text: str
    rationale: str
    projected_impact: str
    confidence: float = 0.0  # 0-1


class EvolutionEngine:
    """
    Generates NLRL evolution prompts for Claude Code execution.
    
    This engine doesn't call an LLM directly — it produces structured
    prompts that the researcher feeds to Claude Code. This keeps the
    human in the loop while leveraging LLM reasoning for policy mutation.
    """

    def __init__(self, store: Store):
        self.store = store

    def build_evolution_context(self, program: ResearchProgram) -> EvolutionContext:
        """Assemble all context needed for a policy evolution step."""
        # Get the latest active policy
        current_policy = None
        if program.evolution_policies:
            current_policy = program.evolution_policies[-1]
        else:
            current_policy = EvolutionPolicy(
                policy_text="Explore broadly, prioritize approaches with clear measurable signals.",
                domain="general",
                generation=0,
            )

        # Collect recent experiments
        recent = self.store.list_experiments()
        recent_completed = [
            e for e in recent
            if e.status in (ExperimentStatus.COMPLETED, ExperimentStatus.FAILED)
        ][-20:]  # last 20

        # Build program status
        from .engine import PhaseEngine
        engine = PhaseEngine(self.store)
        status = engine.get_program_status(program)

        return EvolutionContext(
            current_policy=current_policy,
            recent_experiments=recent_completed,
            program_status=status,
        )

    def generate_evaluation_prompt(self, ctx: EvolutionContext) -> str:
        """Generate a prompt for evaluating the current policy."""
        experiments_summary = self._format_experiments(ctx.recent_experiments)

        return f"""# NLRL Policy Evaluation

## Current Research Policy (Generation {ctx.current_policy.generation})
{ctx.current_policy.policy_text}

## Program Status
{json.dumps(ctx.program_status, indent=2)}

## Recent Experiment Results
{experiments_summary}

## Task
Evaluate the current research policy against the observed experiment outcomes.
Provide:

1. **Fitness Score** (0-1): How well did the policy guide productive research?
2. **Strengths**: What aspects of the policy led to good decisions?
3. **Weaknesses**: Where did the policy fail to anticipate or guide?
4. **Key Observations**: Patterns in the data the policy doesn't capture.

Respond in JSON:
```json
{{
  "fitness_score": 0.0,
  "strengths": ["..."],
  "weaknesses": ["..."],
  "observations": ["..."],
  "should_mutate": true
}}
```
"""

    def generate_mutation_prompt(
        self,
        ctx: EvolutionContext,
        evaluation: dict | None = None,
    ) -> str:
        """Generate a prompt for proposing policy mutations."""
        eval_section = ""
        if evaluation:
            eval_section = f"""## Policy Evaluation Results
- Fitness: {evaluation.get('fitness_score', 'N/A')}
- Strengths: {json.dumps(evaluation.get('strengths', []))}
- Weaknesses: {json.dumps(evaluation.get('weaknesses', []))}
- Observations: {json.dumps(evaluation.get('observations', []))}
"""

        experiments_summary = self._format_experiments(ctx.recent_experiments)

        return f"""# NLRL Policy Mutation

## Current Policy (Generation {ctx.current_policy.generation})
{ctx.current_policy.policy_text}

{eval_section}

## Recent Experiments
{experiments_summary}

## Task
Propose 3 candidate mutations of the current research policy.
Each mutation should address identified weaknesses while preserving strengths.

Mutation types to consider:
- **Refine**: Sharpen existing guidance based on evidence
- **Pivot**: Shift focus based on surprising findings
- **Expand**: Add new guidance for uncovered situations
- **Prune**: Remove guidance that doesn't help

For each candidate, provide:
1. The full mutated policy text
2. What changed and why (mutation rationale)
3. Projected impact on next phase
4. Confidence score (0-1)

Respond in JSON:
```json
{{
  "candidates": [
    {{
      "policy_text": "...",
      "rationale": "...",
      "projected_impact": "...",
      "confidence": 0.0,
      "mutation_type": "refine|pivot|expand|prune"
    }}
  ]
}}
```
"""

    def generate_selection_prompt(
        self,
        ctx: EvolutionContext,
        candidates: list[dict],
    ) -> str:
        """Generate a prompt for selecting the best mutation."""
        candidates_text = "\n".join(
            f"### Candidate {i+1} ({c.get('mutation_type', 'unknown')})\n"
            f"**Policy:** {c['policy_text']}\n"
            f"**Rationale:** {c['rationale']}\n"
            f"**Projected Impact:** {c['projected_impact']}\n"
            f"**Confidence:** {c['confidence']}\n"
            for i, c in enumerate(candidates)
        )

        return f"""# NLRL Policy Selection

## Current Policy (Generation {ctx.current_policy.generation})
{ctx.current_policy.policy_text}

## Program Status
{json.dumps(ctx.program_status, indent=2)}

## Candidate Mutations
{candidates_text}

## Task
Select the best candidate mutation OR recommend keeping the current policy.

Consider:
1. Does the mutation address real observed weaknesses?
2. Is the mutation falsifiable (can we tell if it's working)?
3. Does it maintain sufficient exploration breadth?
4. Is the confidence justified by the evidence?

Respond in JSON:
```json
{{
  "selected": 0,  // 0-indexed candidate number, or -1 to keep current
  "reasoning": "...",
  "modifications": "any final tweaks to the selected candidate"
}}
```
"""

    def apply_mutation(
        self,
        program: ResearchProgram,
        new_policy_text: str,
        mutation_log: str,
        domain: str = "general",
    ) -> EvolutionPolicy:
        """Apply a selected mutation, creating a new policy generation."""
        parent = program.evolution_policies[-1] if program.evolution_policies else None

        new_policy = EvolutionPolicy(
            policy_text=new_policy_text,
            domain=domain,
            generation=(parent.generation + 1) if parent else 1,
            parent_id=parent.id if parent else None,
            mutation_log=mutation_log,
        )

        program.evolution_policies.append(new_policy)
        self.store.save_policy(new_policy, program.id)
        self.store.save_program(
            program,
            f"Evolve policy → gen {new_policy.generation}: {new_policy_text[:60]}",
        )
        return new_policy

    def generate_claude_code_task(
        self,
        program: ResearchProgram,
        experiment: Experiment,
    ) -> str:
        """Generate a Claude Code-ready task prompt for an experiment."""
        policy_text = ""
        if program.evolution_policies:
            policy_text = program.evolution_policies[-1].policy_text

        return f"""# Experiment Task: {experiment.name}

## Research Context
**Program:** {program.name}
**Hypothesis:** {experiment.hypothesis}

## Active Research Policy
{policy_text or "No active policy — explore freely."}

## Experiment Configuration
```json
{json.dumps(experiment.config.parameters, indent=2)}
```

## Instructions
1. Implement and run this experiment
2. Record all metrics in a JSON file: `results.json`
3. Save any artifacts to `./artifacts/`
4. If the experiment fails, document the failure mode

## Expected Output
A `results.json` file with:
```json
{{
  "metrics": {{"metric_name": value}},
  "artifacts": ["path/to/artifact"],
  "notes": "observations from the run",
  "error": null
}}
```
"""

    # ── Helpers ───────────────────────────────────────────────────

    @staticmethod
    def _format_experiments(experiments: list[Experiment]) -> str:
        if not experiments:
            return "No experiments recorded yet."

        lines = []
        for exp in experiments:
            metrics = ""
            if exp.result and exp.result.metrics:
                metrics = ", ".join(f"{k}={v:.4f}" for k, v in exp.result.metrics.items())
            status_icon = "✓" if exp.status == ExperimentStatus.COMPLETED else "✗"
            lines.append(
                f"  {status_icon} [{exp.id}] {exp.name}: {metrics or exp.status.value}"
            )
        return "\n".join(lines)
