"""
SERE CLI — Self-Evolving Research Engine.

Designed for integration with Claude Code:
  $ sere init                          # Initialize workspace
  $ sere program create                # Create a research program
  $ sere phase activate <program>      # Start next phase
  $ sere track add <program> <phase>   # Add a parallel bet
  $ sere exp run <program> <track>     # Record an experiment
  $ sere evolve <program>              # Trigger policy evolution
  $ sere status <program>              # View program status
  $ sere log                           # Git-backed audit trail
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import click
import yaml

from .models import (
    Experiment,
    ExperimentConfig,
    ExperimentResult,
    ExperimentStatus,
    EvolutionPolicy,
    Phase,
    PhaseStatus,
    PhaseType,
    ResearchProgram,
    Track,
)
from .store import Store
from .engine import PhaseEngine
from .evolution import EvolutionEngine


def _find_workspace() -> Path:
    """Walk up to find the nearest .sere workspace."""
    current = Path.cwd()
    while current != current.parent:
        if (current / ".sere").exists():
            return current
        current = current.parent
    return Path.cwd()


def _get_store() -> Store:
    root = _find_workspace()
    store = Store(root)
    if not store.is_workspace():
        click.echo("Not a SERE workspace. Run 'sere init' first.", err=True)
        sys.exit(1)
    return store


def _resolve_program(store: Store, program_ref: str) -> ResearchProgram:
    """Resolve a program by ID or name prefix."""
    programs = store.list_programs()
    # Try exact ID match
    for p in programs:
        if p["id"] == program_ref:
            return store.load_program(p["id"])
    # Try name prefix match
    matches = [p for p in programs if p["name"].lower().startswith(program_ref.lower())]
    if len(matches) == 1:
        return store.load_program(matches[0]["id"])
    if len(matches) > 1:
        click.echo(f"Ambiguous program reference '{program_ref}'. Matches:", err=True)
        for m in matches:
            click.echo(f"  {m['id']}  {m['name']}", err=True)
        sys.exit(1)
    click.echo(f"Program not found: {program_ref}", err=True)
    sys.exit(1)


# ── CLI Group ────────────────────────────────────────────────────

@click.group()
@click.version_option(version="0.1.0")
def cli():
    """SERE — Self-Evolving Research Engine.

    A framework for managing research programs with parallel tracks,
    phase transitions, and NLRL-based policy evolution.
    """
    pass


# ── Init ─────────────────────────────────────────────────────────

@cli.command()
@click.option("--path", default=".", help="Path to initialize workspace")
def init(path: str):
    """Initialize a new SERE workspace."""
    root = Path(path).resolve()
    store = Store(root)
    store.init()
    click.echo(f"Initialized SERE workspace at {root}")


# ── Program commands ─────────────────────────────────────────────

@cli.group()
def program():
    """Manage research programs."""
    pass


@program.command("create")
@click.option("--name", prompt="Program name", help="Name of the research program")
@click.option("--hypothesis", prompt="Research hypothesis", help="Overarching hypothesis")
@click.option("--from-yaml", "yaml_file", help="Create from a YAML template")
def program_create(name: str, hypothesis: str, yaml_file: str | None):
    """Create a new research program."""
    store = _get_store()

    if yaml_file:
        data = yaml.safe_load(Path(yaml_file).read_text())
        prog = ResearchProgram.from_dict(data)
    else:
        prog = ResearchProgram(name=name, hypothesis=hypothesis)

        # Add default phases based on the structural framework
        prog.phases = [
            Phase(
                name="Landscape Mapping",
                phase_type=PhaseType.DIVERGE,
                goal="Enumerate viable approaches",
                convergence_criteria="At least 2 distinct approaches identified and characterized",
            ),
            Phase(
                name="Parallel Evaluation",
                phase_type=PhaseType.DIVERGE,
                goal="Evaluate each approach with controlled experiments",
                convergence_criteria="All tracks have comparable benchmark results",
            ),
            Phase(
                name="Selection & Convergence",
                phase_type=PhaseType.CONVERGE,
                goal="Select the winning approach, merge insights",
                convergence_criteria="Single approach selected with documented rationale",
            ),
            Phase(
                name="Scaling & Publication",
                phase_type=PhaseType.EXPLOIT,
                goal="Scale winning approach, prepare deliverables",
                convergence_criteria="Paper draft or system demo complete",
            ),
        ]

        # Add default evolution policy
        prog.evolution_policies = [
            EvolutionPolicy(
                policy_text="Explore broadly. Prioritize approaches with clear measurable signals. Kill approaches that show no improvement after 3 iterations.",
                domain="general",
                generation=0,
            )
        ]

    store.save_program(prog, f"Create program: {prog.name}")
    click.echo(f"Created program: {prog.name} ({prog.id})")
    click.echo(f"  Hypothesis: {prog.hypothesis}")
    click.echo(f"  Phases: {len(prog.phases)}")
    click.echo(f"\nNext: sere phase activate {prog.id}")


@program.command("list")
def program_list():
    """List all research programs."""
    store = _get_store()
    programs = store.list_programs()
    if not programs:
        click.echo("No programs found. Create one with: sere program create")
        return
    for p in programs:
        click.echo(f"  {p['id']}  {p['name']}")
        if p.get("hypothesis"):
            click.echo(f"           {p['hypothesis'][:80]}")


@program.command("show")
@click.argument("program_ref")
def program_show(program_ref: str):
    """Show detailed program status."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    status = engine.get_program_status(prog)

    click.echo(f"\n{'=' * 60}")
    click.echo(f"  {status['program']}")
    click.echo(f"  {prog.hypothesis}")
    click.echo(f"{'=' * 60}")

    for phase in status["phases"]:
        icon = {"pending": "○", "active": "●", "completed": "✓", "killed": "✗"}
        click.echo(
            f"\n  {icon.get(phase['status'], '?')} [{phase['type'].upper()}] {phase['name']}"
        )
        click.echo(f"    Goal: {phase['goal']}")
        click.echo(f"    Status: {phase['status']}")
        t = phase["tracks"]
        click.echo(f"    Tracks: {t['active']} active, {t['killed']} killed, {t['merged']} merged")
        e = phase["experiments"]
        click.echo(f"    Experiments: {e['completed']}/{e['total']} completed, {e['failed']} failed")

    if prog.evolution_policies:
        latest = prog.evolution_policies[-1]
        click.echo(f"\n  Policy (gen {latest.generation}): {latest.policy_text[:80]}...")
    click.echo()


# ── Phase commands ───────────────────────────────────────────────

@cli.group()
def phase():
    """Manage research phases."""
    pass


@phase.command("activate")
@click.argument("program_ref")
def phase_activate(program_ref: str):
    """Activate the next pending phase."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    phase = engine.activate_next_phase(prog)
    if phase:
        click.echo(f"Activated phase: {phase.name} ({phase.id})")
        click.echo(f"  Type: {phase.phase_type.value}")
        click.echo(f"  Goal: {phase.goal}")
    else:
        click.echo("No more phases to activate.")


@phase.command("complete")
@click.argument("program_ref")
@click.argument("phase_id")
@click.option("--rationale", prompt="Completion rationale", help="Why this phase is complete")
def phase_complete(program_ref: str, phase_id: str, rationale: str):
    """Mark a phase as completed."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    p = engine.complete_phase(prog, phase_id, rationale)
    click.echo(f"Completed phase: {p.name}")
    click.echo(f"\nNext: sere phase activate {prog.id}")


# ── Track commands ───────────────────────────────────────────────

@cli.group()
def track():
    """Manage parallel research tracks."""
    pass


@track.command("add")
@click.argument("program_ref")
@click.argument("phase_id")
@click.option("--name", prompt="Track name", help="Name for the research track")
@click.option("--approach", prompt="Approach description", help="What this track explores")
def track_add(program_ref: str, phase_id: str, name: str, approach: str):
    """Add a parallel research track to a phase."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    t = engine.add_track(prog, phase_id, name, approach)
    click.echo(f"Added track: {t.name} ({t.id})")
    click.echo(f"  Approach: {t.approach}")


@track.command("kill")
@click.argument("program_ref")
@click.argument("phase_id")
@click.argument("track_id")
@click.option("--reason", prompt="Kill reason", help="Why this track is being abandoned")
def track_kill(program_ref: str, phase_id: str, track_id: str, reason: str):
    """Kill an underperforming track."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    t = engine.kill_track(prog, phase_id, track_id, reason)
    click.echo(f"Killed track: {t.name}")


@track.command("merge")
@click.argument("program_ref")
@click.argument("phase_id")
@click.argument("track_id")
@click.option("--notes", prompt="Merge notes", help="Insights to carry forward")
def track_merge(program_ref: str, phase_id: str, track_id: str, notes: str):
    """Merge a track's insights during convergence."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    t = engine.merge_track(prog, phase_id, track_id, notes)
    click.echo(f"Merged track: {t.name}")


# ── Experiment commands ──────────────────────────────────────────

@cli.group()
def exp():
    """Manage experiments."""
    pass


@exp.command("record")
@click.argument("program_ref")
@click.option("--track", "track_id", required=True, help="Track ID")
@click.option("--phase", "phase_id", required=True, help="Phase ID")
@click.option("--name", prompt="Experiment name", help="Short name")
@click.option("--hypothesis", default="", help="What you expect to observe")
@click.option("--params", default="{}", help="JSON parameters")
@click.option("--seed", type=int, default=None, help="Random seed")
def exp_record(
    program_ref: str,
    track_id: str,
    phase_id: str,
    name: str,
    hypothesis: str,
    params: str,
    seed: int | None,
):
    """Record a new experiment."""
    store = _get_store()
    _resolve_program(store, program_ref)  # validate program exists

    config = ExperimentConfig(
        parameters=json.loads(params),
        seed=seed,
    )
    experiment = Experiment(
        name=name,
        hypothesis=hypothesis,
        config=config,
        status=ExperimentStatus.RUNNING,
        track_id=track_id,
        phase_id=phase_id,
    )
    store.save_experiment(experiment)
    click.echo(f"Recorded experiment: {experiment.name} ({experiment.id})")
    click.echo(f"  Config hash: {config.content_hash()}")
    click.echo(f"  Status: running")


@exp.command("complete")
@click.argument("experiment_id")
@click.option("--metrics", default="{}", help="JSON metrics dict")
@click.option("--error", default=None, help="Error message if failed")
@click.option("--notes", default="", help="Observations")
def exp_complete(experiment_id: str, metrics: str, error: str | None, notes: str):
    """Record experiment completion with results."""
    store = _get_store()
    experiment = store.load_experiment(experiment_id)
    if not experiment:
        click.echo(f"Experiment not found: {experiment_id}", err=True)
        sys.exit(1)

    experiment.result = ExperimentResult(
        metrics=json.loads(metrics),
        error=error,
    )
    experiment.status = ExperimentStatus.FAILED if error else ExperimentStatus.COMPLETED
    experiment.completed_at = datetime.now(timezone.utc).isoformat()
    experiment.notes = notes
    store.save_experiment(experiment)

    status_str = "FAILED" if error else "COMPLETED"
    click.echo(f"Experiment {experiment.name}: {status_str}")
    if experiment.result.metrics:
        for k, v in experiment.result.metrics.items():
            click.echo(f"  {k}: {v}")


@exp.command("list")
@click.option("--phase", "phase_id", default=None, help="Filter by phase")
@click.option("--track", "track_id", default=None, help="Filter by track")
@click.option("--status", default=None, help="Filter by status")
def exp_list(phase_id: str | None, track_id: str | None, status: str | None):
    """List experiments with optional filters."""
    store = _get_store()
    status_enum = ExperimentStatus(status) if status else None
    experiments = store.list_experiments(
        phase_id=phase_id,
        track_id=track_id,
        status=status_enum,
    )
    if not experiments:
        click.echo("No experiments found.")
        return
    for e in experiments:
        icon = {"completed": "✓", "failed": "✗", "running": "▶", "planned": "○", "killed": "⊘"}
        metrics_str = ""
        if e.result and e.result.metrics:
            metrics_str = " | " + ", ".join(f"{k}={v:.4f}" for k, v in e.result.metrics.items())
        click.echo(
            f"  {icon.get(e.status.value, '?')} [{e.id}] {e.name}{metrics_str}"
        )


# ── Evolution commands ───────────────────────────────────────────

@cli.group()
def evolve():
    """NLRL-based policy evolution."""
    pass


@evolve.command("evaluate")
@click.argument("program_ref")
def evolve_evaluate(program_ref: str):
    """Generate a policy evaluation prompt for Claude Code."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    evo = EvolutionEngine(store)
    ctx = evo.build_evolution_context(prog)
    prompt = evo.generate_evaluation_prompt(ctx)
    click.echo(prompt)


@evolve.command("mutate")
@click.argument("program_ref")
@click.option("--eval-json", default=None, help="Path to evaluation results JSON")
def evolve_mutate(program_ref: str, eval_json: str | None):
    """Generate a policy mutation prompt for Claude Code."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    evo = EvolutionEngine(store)
    ctx = evo.build_evolution_context(prog)

    evaluation = None
    if eval_json:
        evaluation = json.loads(Path(eval_json).read_text())

    prompt = evo.generate_mutation_prompt(ctx, evaluation)
    click.echo(prompt)


@evolve.command("apply")
@click.argument("program_ref")
@click.option("--policy", prompt="New policy text", help="The evolved policy")
@click.option("--rationale", prompt="Mutation rationale", help="What changed and why")
@click.option("--domain", default="general", help="Policy domain")
def evolve_apply(program_ref: str, policy: str, rationale: str, domain: str):
    """Apply a policy mutation."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    evo = EvolutionEngine(store)
    new = evo.apply_mutation(prog, policy, rationale, domain)
    click.echo(f"Applied policy mutation → generation {new.generation}")
    click.echo(f"  Policy: {new.policy_text[:80]}...")


@evolve.command("history")
@click.argument("program_ref")
def evolve_history(program_ref: str):
    """Show policy evolution history."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    history = store.load_policy_history(prog.id)
    if not history:
        click.echo("No evolution history yet.")
        return
    for p in history:
        click.echo(f"  Gen {p.generation}: {p.policy_text[:70]}...")
        if p.mutation_log:
            click.echo(f"        Δ {p.mutation_log[:70]}")


@evolve.command("task")
@click.argument("program_ref")
@click.argument("experiment_id")
def evolve_task(program_ref: str, experiment_id: str):
    """Generate a Claude Code task prompt for an experiment."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    exp_obj = store.load_experiment(experiment_id)
    if not exp_obj:
        click.echo(f"Experiment not found: {experiment_id}", err=True)
        sys.exit(1)
    evo = EvolutionEngine(store)
    prompt = evo.generate_claude_code_task(prog, exp_obj)
    click.echo(prompt)


# ── Audit trail ──────────────────────────────────────────────────

@cli.command()
@click.option("-n", default=20, help="Number of entries")
def log(n: int):
    """Show the git-backed audit trail."""
    store = _get_store()
    entries = store.get_log(n)
    for entry in entries:
        click.echo(f"  {entry['hash'][:8]}  {entry['date']}  {entry['message']}")


# ── Status (convenience) ────────────────────────────────────────

@cli.command()
@click.argument("program_ref")
def status(program_ref: str):
    """Quick status overview (alias for program show)."""
    store = _get_store()
    prog = _resolve_program(store, program_ref)
    engine = PhaseEngine(store)
    s = engine.get_program_status(prog)

    click.echo(f"\n  {s['program']}")
    if s["current_phase"]:
        click.echo(f"  Current phase: {s['current_phase']}")
    else:
        click.echo("  No active phase")
    click.echo(f"  Policies: {s['policies']} generations")

    total_exps = sum(p["experiments"]["total"] for p in s["phases"])
    total_completed = sum(p["experiments"]["completed"] for p in s["phases"])
    click.echo(f"  Experiments: {total_completed}/{total_exps} completed\n")


def main():
    cli()
