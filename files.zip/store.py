"""
SERE Storage — Git-backed experiment tracking.

Every state change is committed to a local git repo, giving full
reproducibility and audit trail. The store manages:
  - Research program state (YAML)
  - Experiment registry (JSON lines)
  - Evolution policy history (JSON)
  - Artifact references
"""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from .models import (
    Experiment,
    ExperimentStatus,
    EvolutionPolicy,
    ResearchProgram,
)


class Store:
    """Git-backed research program store."""

    def __init__(self, root: Path):
        self.root = Path(root)
        self.programs_dir = self.root / "programs"
        self.experiments_dir = self.root / "experiments"
        self.policies_dir = self.root / "policies"
        self.artifacts_dir = self.root / "artifacts"

    def init(self) -> None:
        """Initialize a new SERE workspace."""
        for d in [self.programs_dir, self.experiments_dir, self.policies_dir, self.artifacts_dir]:
            d.mkdir(parents=True, exist_ok=True)

        # Initialize git repo if not already
        if not (self.root / ".git").exists():
            self._git("init")
            # Ensure git has a user identity for commits
            self._git("config", "user.email", "sere@local")
            self._git("config", "user.name", "SERE")
            # Write .gitignore
            gitignore = self.root / ".gitignore"
            gitignore.write_text("__pycache__/\n*.pyc\n.venv/\n")
            self._git("add", ".")
            self._git("commit", "-m", "Initialize SERE workspace")

        # Write workspace marker
        marker = self.root / ".sere"
        if not marker.exists():
            marker.write_text(json.dumps({
                "version": "0.1.0",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }))

    def is_workspace(self) -> bool:
        return (self.root / ".sere").exists()

    # ── Program CRUD ──────────────────────────────────────────────

    def save_program(self, program: ResearchProgram, message: str = "") -> None:
        """Save program state and commit."""
        program.updated_at = datetime.now(timezone.utc).isoformat()
        path = self.programs_dir / f"{program.id}.yaml"
        path.write_text(yaml.dump(program.to_dict(), default_flow_style=False, sort_keys=False))
        self._commit(path, message or f"Update program: {program.name}")

    def load_program(self, program_id: str) -> ResearchProgram:
        path = self.programs_dir / f"{program_id}.yaml"
        if not path.exists():
            raise FileNotFoundError(f"Program not found: {program_id}")
        data = yaml.safe_load(path.read_text())
        return ResearchProgram.from_dict(data)

    def list_programs(self) -> list[dict[str, str]]:
        programs = []
        for path in sorted(self.programs_dir.glob("*.yaml")):
            data = yaml.safe_load(path.read_text())
            programs.append({
                "id": data["id"],
                "name": data["name"],
                "hypothesis": data.get("hypothesis", ""),
                "created_at": data.get("created_at", ""),
                "updated_at": data.get("updated_at", ""),
            })
        return programs

    def delete_program(self, program_id: str) -> None:
        path = self.programs_dir / f"{program_id}.yaml"
        if path.exists():
            path.unlink()
            self._commit(path, f"Delete program: {program_id}")

    # ── Experiment tracking ───────────────────────────────────────

    def save_experiment(self, experiment: Experiment) -> None:
        """Append experiment to the registry (JSON lines format)."""
        registry = self.experiments_dir / "registry.jsonl"
        with open(registry, "a") as f:
            f.write(json.dumps(experiment.to_dict()) + "\n")
        self._commit(registry, f"Record experiment: {experiment.name} [{experiment.status.value}]")

    def load_experiment(self, experiment_id: str) -> Experiment | None:
        """Load the latest state of an experiment."""
        registry = self.experiments_dir / "registry.jsonl"
        if not registry.exists():
            return None
        # Read in reverse to get the latest entry for this ID
        latest = None
        for line in registry.read_text().strip().split("\n"):
            if not line:
                continue
            entry = json.loads(line)
            if entry["id"] == experiment_id:
                latest = entry
        return Experiment.from_dict(latest) if latest else None

    def list_experiments(
        self,
        program_id: str | None = None,
        phase_id: str | None = None,
        track_id: str | None = None,
        status: ExperimentStatus | None = None,
    ) -> list[Experiment]:
        """Query experiments with optional filters."""
        registry = self.experiments_dir / "registry.jsonl"
        if not registry.exists():
            return []

        # Collect latest state per experiment ID
        latest: dict[str, dict] = {}
        for line in registry.read_text().strip().split("\n"):
            if not line:
                continue
            entry = json.loads(line)
            latest[entry["id"]] = entry

        experiments = [Experiment.from_dict(e) for e in latest.values()]

        if phase_id:
            experiments = [e for e in experiments if e.phase_id == phase_id]
        if track_id:
            experiments = [e for e in experiments if e.track_id == track_id]
        if status:
            experiments = [e for e in experiments if e.status == status]

        return sorted(experiments, key=lambda e: e.created_at)

    # ── Evolution policy history ──────────────────────────────────

    def save_policy(self, policy: EvolutionPolicy, program_id: str) -> None:
        """Append policy to history."""
        history_path = self.policies_dir / f"{program_id}.jsonl"
        with open(history_path, "a") as f:
            f.write(json.dumps(policy.to_dict()) + "\n")
        self._commit(
            history_path,
            f"Evolve policy gen={policy.generation}: {policy.policy_text[:60]}",
        )

    def load_policy_history(self, program_id: str) -> list[EvolutionPolicy]:
        history_path = self.policies_dir / f"{program_id}.jsonl"
        if not history_path.exists():
            return []
        policies = []
        for line in history_path.read_text().strip().split("\n"):
            if not line:
                continue
            policies.append(EvolutionPolicy.from_dict(json.loads(line)))
        return policies

    # ── Git operations ────────────────────────────────────────────

    def _git(self, *args: str) -> str:
        result = subprocess.run(
            ["git"] + list(args),
            cwd=self.root,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()

    def _commit(self, path: Path, message: str) -> None:
        """Stage and commit a single file."""
        rel = path.relative_to(self.root)
        self._git("add", str(rel))
        # Only commit if there are staged changes
        status = self._git("diff", "--cached", "--name-only")
        if status:
            self._git("commit", "-m", message)

    def get_log(self, n: int = 20) -> list[dict[str, str]]:
        """Return recent git commits as audit trail."""
        raw = self._git(
            "log",
            f"-{n}",
            "--format=%H|||%ai|||%s",
        )
        entries = []
        for line in raw.split("\n"):
            if "|||" not in line:
                continue
            parts = line.split("|||")
            entries.append({
                "hash": parts[0].strip(),
                "date": parts[1].strip(),
                "message": parts[2].strip(),
            })
        return entries
